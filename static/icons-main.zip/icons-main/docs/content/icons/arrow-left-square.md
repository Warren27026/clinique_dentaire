---
title: Arrow left square
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
