---
title: 7 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
