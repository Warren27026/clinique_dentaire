---
title: Arrow up square
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
