---
title: Arrow up right square
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
